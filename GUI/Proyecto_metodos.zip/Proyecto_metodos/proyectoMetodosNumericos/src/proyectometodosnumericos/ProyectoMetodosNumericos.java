/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectometodosnumericos;

import javax.swing.JFrame;

/**
 *
 * @author Usuario
 */
public class ProyectoMetodosNumericos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            Vista ventana = new Vista(); // Instancia del objeto de la clse Vista
	    ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
