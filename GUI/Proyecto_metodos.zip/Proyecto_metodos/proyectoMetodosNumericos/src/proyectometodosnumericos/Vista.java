/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectometodosnumericos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.net.MalformedURLException;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Usuario
 */
public class Vista extends JFrame implements MouseListener{
  
        private JButton cargarImagen, ejecutar;
        private JFileChooser explorador;
        private JPanel panelSuperior, panelInferior;
        private JLabel imageToAnalize;
        private JTextArea resultPrediction;
        
        private String ruta;
      //  private int prediccion;
      //  private double valorPrediccion;
        
	private Control obj;
        private FileNameExtensionFilter filtroImagen;

    public Vista() {
        
        	super("Proyecto Metodos Numericos");
		
		Container contenedor = getContentPane();
		contenedor.setLayout(new BorderLayout());
		
		construyePanelSuperior();
		construyePanelInferior();
		
		contenedor.add(panelSuperior, BorderLayout.NORTH);
		contenedor.add(panelInferior, BorderLayout.CENTER);
		
		obj = new Control();
   
		setResizable(false);
                setSize(560, 510); 
                setLocationRelativeTo(null);
		setVisible(true);
        
    }
    
    void construyePanelSuperior(){
        panelSuperior = new JPanel ();
        panelSuperior.setLayout(new FlowLayout());
        
        imageToAnalize = new JLabel();
     //   imageToAnalize.setBackground(Color.BLACK);
   //     imageToAnalize.setSize(270,300);
   
   
   // create a line border with the specified color and width

        Border border = BorderFactory.createLineBorder(Color.BLUE, 5);

 
        // set the border of this component

        imageToAnalize.setBorder(border);

   
        panelSuperior.add(imageToAnalize);
        
        resultPrediction = new JTextArea();
        //    resultPrediction.setBounds(0, 0, 200, 200);
        
        Font fuente=new Font("Dialog", Font.BOLD, 50);
        
        resultPrediction.setFont(fuente);
       
        panelSuperior.add(resultPrediction);
   
        }
    
	/*
	 *  Metodo que construye el panel inferior.
	 */

    void construyePanelInferior(){
        panelInferior= new JPanel();
        panelInferior.setLayout(new FlowLayout());      
        
        cargarImagen = new JButton("cargar");
        cargarImagen.addMouseListener(this);
        panelInferior.add(cargarImagen);
        
        ejecutar = new JButton("ejecutar");
    //    ejecutar.addMouseListener(this);
        ejecutar.setEnabled(false);
        panelInferior.add(ejecutar);
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent evento) {
        
        if (evento.getSource() ==  cargarImagen) {
            
        JFileChooser explorador = new JFileChooser();
        
        //Le cambiamos el titulo
        explorador.setDialogTitle("Cargar imagen...");

        //Agregamos un filtro de extensiones
        filtroImagen = new FileNameExtensionFilter("JPG, PNG & GIF","jpg","png","gif");
        explorador.setFileFilter(filtroImagen);
        
        //Muestro un dialogo sin pasarle parent con el boton de abrir
        int seleccion = explorador.showDialog(null, "Abrir!");
  
        //analizamos la respuesta
        switch(seleccion) {
        case JFileChooser.APPROVE_OPTION:
        //seleccionó abrir
            try {
                //Podemos crear un File con lo seleccionado
                File archivo = explorador.getSelectedFile();

                //y guardar una ruta
                ruta = archivo.getPath();
                resultPrediction.setText(ruta);
                
                ImageIcon imagen =new ImageIcon(ruta);
                Icon icono = new ImageIcon(imagen.getImage().
                        getScaledInstance(/*imageToAnalize.getWidth()*/200, /*imageToAnalize.getHeight()*/200, Image.SCALE_DEFAULT));
                imageToAnalize.setIcon(icono);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        break;

        case JFileChooser.CANCEL_OPTION:
        //dio click en cancelar o cerro la ventana
        break;

        case JFileChooser.ERROR_OPTION:
        //llega aqui si sucede un error
        break;
        }
         
        
        ejecutar.setEnabled(true);
        ejecutar.addMouseListener(this);
        }
        
        if (evento.getSource() ==  ejecutar) {
                    
                ejecutar.setEnabled(false);
                ejecutar.removeMouseListener(this);
            
            	obj.llenarBase(300);
		obj.llenarMatrices();
		obj.convertirImagen(ruta);
		obj.comparacion();
		
                double valorPrediccion = 1000000;
                int prediccion = 0;
                double valor;
                
                String resultado;
                
		for(int i = 0; i<10;i++)
		{
                    System.out.println(i+" "+(obj.getValores())[i]);
                    
                    valor = obj.getValores()[i];
                    valor = ( (double)( (int) (valor *1000000)) ) /1000000;
                    
                    System.out.println(valor);
                        
                    if (valor < valorPrediccion) {
                        
                        System.out.println("el valor" + i + " tiene " + valor);
                        prediccion = i;
                        valorPrediccion = valor;
                    }
		}
                
                resultado = String.valueOf(prediccion);
                resultPrediction.setText(resultado);

        }
 
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
    
        
}
