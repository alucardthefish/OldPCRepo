<?php
function conectar()
{
	mysql_connect("localhost", "root", "");// conectarse al servidor de bases de datos
	mysql_select_db("univalle");       // seectcionar la bases de datos
}

function desconectar()
{
	mysql_close(); // desconectarse de la base de datos
}
?>