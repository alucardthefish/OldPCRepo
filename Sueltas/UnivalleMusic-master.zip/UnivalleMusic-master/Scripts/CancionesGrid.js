Ext.form.Field.prototype.msgTarget = 'side';

var ds = new Ext.data.Store(
{
  reader: new Ext.data.ArrayReader({}, 
  [
    {name: 'titulo'},
    {name: 'artista'},
    {name: 'album'},
    {name: 'genero'},
    {name: 'megusta'}
  ])
});

var st = new Ext.data.SimpleStore(
{
  fields: [{name: 'titulo'}],
  reader: new Ext.data.ArrayReader({}, [{name: 'titulo'},])
});
    
var colModel = new Ext.grid.ColumnModel(
[
{id:'titulo', header: "Titulo", width: 100, sortable: true, locked:false, dataIndex: 'titulo'},
{id:'artista', header: "Artista", width: 100, sortable: true, locked:false, dataIndex: 'artista'},
{id:'album', header: "Album", width: 70, sortable: true, locked:false, dataIndex: 'album'},
{id:'genero', header: "Genero", width: 50, sortable: true, locked:false, dataIndex: 'genero'}
]);

function crearGrilla(){  
  cancionesGrid = new Ext.grid.GridPanel({
    ds: ds,
    cm: colModel,
    renderTo: 'cancionesGrid' 
  });
}


Ext.onReady(function(){
    
  //Ext.BLANK_IMAGE_URL = '../Assets/extjs/s.gif';
  Ext.QuickTips.init();
   crearGrilla(); //Invoca a la funcion crearGrilla()
   
  });
