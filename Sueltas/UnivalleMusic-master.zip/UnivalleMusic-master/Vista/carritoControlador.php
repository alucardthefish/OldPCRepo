<?php
//Todo HTMl que se imprima en este archivo corresponde al valor de respuesta y mostrado en el alert()
echo $_POST["nombre"]." ".$_POST["apellido"];


?>